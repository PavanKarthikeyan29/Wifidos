Subcribe to our Channel :)

This Video For educational Purpose Only

Command1 - sudo su
Command2 - mkdir dos
Command3 - cd dos
Command4 - git clone "Link In Description"
Command5 - gzip -d dos.zip
Command6 - python or python3 wifidos.py

And Enjoy Your Attack :)